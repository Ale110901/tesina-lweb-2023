<hr id="riga-sezioni" />
<div id="footer" class="centrato">
  <div id="sopra" class="py-1em">
    <div>
      <h3 class="pb-8">Contatti</h3>
      <p id="contatti">
        &#x01F4E7 cecchetto.1941039@studenti.uniroma1.it<br>
        &#x01F4E7 roccia.1967318@studenti.uniroma1.it<br>
        &#x01F4DE +39 07731234567
      </p>
    </div>
    <div>
      <h3 class="pb-8">Dove siamo</h3>
      &#x01F4CC Via XXIV Maggio, 7, 04100 Latina LT
    </div>
  </div>
  <div id="sotto" class="py-1em">
    Copyright R&amp;C store 2023
  </div>
</div>
