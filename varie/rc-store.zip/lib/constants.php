<?php
const REGEX_CF = '/^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$/';
const REGEX_EMAIL = '/^[A-Za-z0-9._\-]+@[A-Za-zA0-9._\-]+\.[A-Za-z]+$/';
const REGEX_INDIRIZZO = '/^([[:alnum:] ]+), ([a-zA-Z ]+), ([a-zA-Z ]+)$/';
const REGEX_PASSWORD = '/^[A-Za-z0-9!£$%&()=?^,.;:_|]{8,}$/';
const REGEX_TELEFONO = '/^\+[0-9]{12,13}$/';
?>
